<?php


namespace Mod\PriceView\Model\ResourceModel;

use Magento\CatalogRule\Model\ResourceModel\Rule;

class RulePrice extends Rule
{

}
