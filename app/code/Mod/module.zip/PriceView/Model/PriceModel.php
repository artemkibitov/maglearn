<?php


namespace Mod\PriceView\Model;


use Mod\PriceView\Model\ResourceModel\RulePrice;

class PriceModel extends RulePrice
{
}
