<?php


namespace Mod\AdminMultiSelect\Model;


use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\Indexer;
use Magento\Framework\Api\AttributeValueFactory;
use Magento\UrlRewrite\Model\UrlFinderInterface;

class Category extends \Magento\Catalog\Model\Category
{
}
