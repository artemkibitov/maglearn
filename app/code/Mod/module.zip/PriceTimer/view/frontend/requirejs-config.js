var config = {
    map: {
        '*' : {
            jquery_countdown : 'Mod_PriceTimer/js/jquery_countdown'
        }
    }
};
